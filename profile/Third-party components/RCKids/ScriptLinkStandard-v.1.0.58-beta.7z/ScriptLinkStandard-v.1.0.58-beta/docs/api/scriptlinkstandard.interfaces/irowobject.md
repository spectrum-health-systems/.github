---
theme: cayman
layout: default
title: IRowObject Interface
---

# IRowObject Interface

Namespace: ScriptLinkStandard.Interfaces

Assemblies: ScriptLinkStandard.dll

Exposes an object that supports the Netsmart-defined RowObject properties and the ScriptLinkStandard methods.

```c#
public interface IRowObject
```
