---
theme: cayman
layout: default
title: IFormObject Interface
---

# IFormObject Interface

Namespace: ScriptLinkStandard.Interfaces

Assemblies: ScriptLinkStandard.dll

Exposes an object that supports the Netsmart-defined FormObject properties and the ScriptLinkStandard methods.

```c#
public interface IFormObject
```
