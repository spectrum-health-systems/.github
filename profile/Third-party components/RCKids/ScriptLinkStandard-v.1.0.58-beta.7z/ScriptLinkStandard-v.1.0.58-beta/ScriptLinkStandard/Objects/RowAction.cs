﻿namespace ScriptLinkStandard.Objects
{
    public static class RowAction
    {
        public const string Add = "ADD";
        public const string Delete = "DELETE";
        public const string Edit = "EDIT";
        public const string None = "";
    }
}
