﻿Public Class OptionObject

    Public EntityID As String

    Public EpisodeNumber As Double

    Public ErrorCode As Double

    Public ErrorMesg As String

    Public Facility As String

    Public Forms() As FormObject

    Public OptionId As String

    Public OptionStaffId As String

    Public OptionUserId As String

    Public SystemCode As String

End Class
